module.exports = {
    USER: 'sa',
    PASSWORD: 'Josh@12345',
    SERVER: 'localhost',
    DATABASE: 'WKG',
    PORT:1433,
    OPTIONS:{
        TRUSTED_CONNECTION:true,
        ENCRYPT:true,
        ENABLEARITHABORT:true,
        TRUST_SERVER_CERTIFICATE:true
    }
}



